﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab = new int[8] { 10, 20, 30, 40, 50, 60, 70, 80 };
            int[] licz = new int[8] { 1, 2, 3, 4, 5, 6, 7, 8 };
            int elem = 1;

            Console.WriteLine("{0}", tab[1]);

         
           for (int i=0; i<7; i++)
            {
                Console.WriteLine("Element {0}: {1} ",licz[i], tab[i]);
            }

            Console.WriteLine();
            Console.WriteLine("Druga metoda foreach");
            Console.WriteLine();

            elem = 1;
           foreach (int item in tab)
            {
                
                Console.WriteLine("Element {0}: {1} ", elem, item);
                elem++;
            }

            Console.WriteLine();
            Console.WriteLine("Zadanie 1");
            Console.WriteLine();


            /* uzytkownik podaje z kalwiatury 3 swoje ulubione kolory
             * przypisz je do tablicy i wyswielt na ekranie w fomracie
             * kolor 1: kolor
             * kolor 2: kolor
             * do przypisania kolorów do tablicy wykorzystaj pętlę for
             * do wyświetlenia kolorów z tablicy wykorzystaj pętlę while
             * */


            string[] colors = new string [3];
            string color;

            for (int i=0; i< colors.Length; i++)
            {
                Console.WriteLine("Podaj kolor:");
                color = Console.ReadLine();
                colors[i] = color;
            }
            uint index=0;
            uint count;
            while(index < colors.Length)
            {
                count = index + 1;
                Console.WriteLine("Kolor {0}: {1}", count, colors[index]);
            }

            Console.ReadKey();
        }
    }
}
