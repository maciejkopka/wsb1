﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*add(2, 3);

            int c = 5;
            int d = 10;

            add(c, d);
            add(c, d, 5);
            Add(c=1,d=2);

            

            Console.WriteLine( "Pole kwadratu: {0}", SquareArea(10));
            Console.WriteLine(" {0}", Add(1,2, c=1, d=2));
            date("Janusz");*/

              /*  string liczba;
                int x;
                Console.WriteLine("Podaj liczbe");
                liczba = Console.ReadLine();
                x = int.Parse(liczba);
                Console.WriteLine("{0}", CheckEvent(x));
                */


            Console.WriteLine(" {0}", Check(123));





            Console.ReadKey();
        }
        static void add(int a, int b)
        {
           int result = a + b;
           Console.WriteLine("Wynik dodawania: {0}", result);
         }
        static void add(int a, int b, int c)
        {
            int result = a + b + c;
            Console.WriteLine("Wynik dodawania: {0}", result);
        }
        static int SquareArea(int a)
        {
            return a * a;
        }
        static int  Add(int c, int d, int a = 5, int b = 10)
        {
            return a + b + c + d;
        }
        static void date(string name, string surname="Nowak", int age = 30)
        {
            Console.WriteLine("Imię: {0}, Nazwisko: {1} ,Wiek: {2}", name, surname, age);
        }
        /*
         * Napisz program który sprawdza czy liczba całkowita podana przez użytkownika jest parzysta/nieparzysta.
         * Napisz funkcje która przyjmuje jako argument liczbę podaną przez użytkownika z klawiatury.
         * Zabezpiecz dane podane z klawiatury przed błędami.
         * 
         * 
         * Napisz funkcje która sumuje cyfry w liczbie
         */
         static string CheckEvent(int x)
        {
            if (x % 2 ==0)
            {
                return "Liczba parzysta";
            }
            else
            {
                return "Liczba nieparzysta";
            }
        }

        static int Check(int a)
        {
            int result = 0;
            do
            {
                result = result + a % 10;
                a = a / 10;
            } while (a != 0);
            return result;


        }
    }
}
