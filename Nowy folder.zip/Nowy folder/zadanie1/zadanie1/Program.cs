﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             
             int suma = 0;
            for(int i=1; i<10; i++)
            {
                if (i % 2 !=0)
                {
                    suma += i;
                }
            } 

            Console.Write("Suma wynosi: {0}", suma); 
            
            WYSWIETLA SUME /2
             
             */
            /*

             NAPISZ PROGRAM KTÓRY WYŚWIETLA DUZE LITERY ALFABETU  OD A DO Z ORAZ OD Z DO A


           char znak = 'A';
           for(;znak<='Z';znak++)
           {
               Console.Write("{0}, ", znak);
           }
           Console.WriteLine();
           char znak2 = 'Z';
           for(;znak2>='A';znak2--)
           {
               Console.Write("{0}, ", znak2);
           }
           Console.ReadKey();
           */

            /* NAPISZ PROGRAM KTORY ZA POMOCA INSTUKCJI WHILE DLA DANYCH WARTOSCI X ZMIENIAJACYCH SIE W PRZEDZIALE 0-10 OBLICZA WARTOSC FUNKCJI Y=4X*/
            /*
            int x = 0;
            int y = 0;
            while(x<=10)
            {
                y = x * 4;
                Console.Write("x={0} y={1}", x, y);
                Console.WriteLine();
                x++;
            }
            Console.ReadKey();
           */

            /*NAPISZ PROGRAM KTORY ZA POMOCA INSTRUKCJI WHILE DLA DANYCH WARTOSCI X Z PRZEDZIALU 1-50 OBLICZY ICH SUME */

            /*
            int x = 1;
            int suma = 0;
            while(x<=50)
            {
                suma = suma + x;
                x++;
            }
            Console.Write("Suma wynosi: {0}", suma);

            Console.ReadKey();
            */

            /*Uzytkownik podaje swoj wiek z klawaitury w przedziale od 1-120. Wykorzystaj instukcje do while do prawidłowego podania danych */

            /*
            string wiek;
            uint age;
            bool error = false;

            do
            {
                Console.Write("Podaj swój wiek:");
                wiek = Console.ReadLine();
                if (uint.TryParse(wiek, out age) == false)
                {
                    error = true;

                }
                else
                {
                    error = false;
                }




            } while (age < 1 || age > 120);
            {
                Console.WriteLine("Twój wiek: {0}", wiek);
            }

            Console.ReadKey();
            */
            int wiersz = 1;
            int kolumna = 1;

            do
            {
                Console.Write("{0} ", wiersz);
                wiersz++;
                do
                {
                    Console.WriteLine("{0} ", n);
                } while ();

            } while (n <= 10);
 


            Console.ReadKey();
        }
        

    }
}
