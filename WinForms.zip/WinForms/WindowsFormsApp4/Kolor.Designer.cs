﻿namespace WindowsFormsApp4
{
    partial class Kolor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label_komunikat = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBok = new System.Windows.Forms.TextBox();
            this.Pokaz_ukryj = new System.Windows.Forms.Button();
            this.buttonKolor = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 263);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Zamknij kolor";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(190, 263);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label_komunikat
            // 
            this.label_komunikat.AutoSize = true;
            this.label_komunikat.ForeColor = System.Drawing.Color.Crimson;
            this.label_komunikat.Location = new System.Drawing.Point(41, 36);
            this.label_komunikat.Name = "label_komunikat";
            this.label_komunikat.Size = new System.Drawing.Size(35, 13);
            this.label_komunikat.TabIndex = 2;
            this.label_komunikat.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Bok";
            // 
            // textBok
            // 
            this.textBok.Location = new System.Drawing.Point(44, 83);
            this.textBok.Name = "textBok";
            this.textBok.Size = new System.Drawing.Size(100, 20);
            this.textBok.TabIndex = 4;
            // 
            // Pokaz_ukryj
            // 
            this.Pokaz_ukryj.Location = new System.Drawing.Point(44, 130);
            this.Pokaz_ukryj.Name = "Pokaz_ukryj";
            this.Pokaz_ukryj.Size = new System.Drawing.Size(75, 23);
            this.Pokaz_ukryj.TabIndex = 5;
            this.Pokaz_ukryj.Text = "Pokaż/Ukryj";
            this.Pokaz_ukryj.UseVisualStyleBackColor = true;
            // 
            // buttonKolor
            // 
            this.buttonKolor.Location = new System.Drawing.Point(44, 185);
            this.buttonKolor.Name = "buttonKolor";
            this.buttonKolor.Size = new System.Drawing.Size(75, 23);
            this.buttonKolor.TabIndex = 6;
            this.buttonKolor.Text = "Kolor";
            this.buttonKolor.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(242, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(0, 0);
            this.panel1.TabIndex = 7;
            // 
            // Kolor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 333);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonKolor);
            this.Controls.Add(this.Pokaz_ukryj);
            this.Controls.Add(this.textBok);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_komunikat);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Kolor";
            this.Text = "Kolor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Kolor_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label_komunikat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBok;
        private System.Windows.Forms.Button Pokaz_ukryj;
        private System.Windows.Forms.Button buttonKolor;
        private System.Windows.Forms.Panel panel1;
    }
}