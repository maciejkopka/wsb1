﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Obliczenia;

namespace biblioteka
{
    class Program
    {
        static void Main(string[] args)
        {
            Kwadrat a = new Kwadrat();
            Prostokat b = new Prostokat();

            Console.WriteLine(a.Add(1));
            Console.WriteLine(b.Add(3,4));

            Console.ReadKey();

        }
    }
}