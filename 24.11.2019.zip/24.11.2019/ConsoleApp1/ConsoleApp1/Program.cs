﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab = new int[2];
            tab[0] = 5;
            tab[1] = 10;
            Console.WriteLine("Wartości tablicy przed wywołaniem funkcji: {0} {1} ", tab[0], tab[1]);
            Tab(tab);
            Console.WriteLine("Wartości tablicy przed wywołaniem funkcji: {0} {1} ", tab[0], tab[1]);

            Console.ReadKey();
        }
        static void Tab(int[] tab)
        {
            tab[0] = 50;
            tab[1] = 100;

            Console.WriteLine("Wartości wewnętrzne funkcji: {0} {1}", tab[0], tab[1]);
        }

    }
}
