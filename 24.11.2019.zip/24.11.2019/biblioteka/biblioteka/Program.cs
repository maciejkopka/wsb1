﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace biblioteka
{
    class Program
    {
        static void Main(string[] args)
        {
            MathClass x = new MathClass();
            
            Console.WriteLine(x.Add(1, 3));

            Console.ReadKey();

        }
    }
}
